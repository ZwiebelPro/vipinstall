How to use VIPERION probably:

First download runtime for Windows:

Simple instruction:

VIPERION is made with .NET runtime and c sharp so
make sure to download it: 1. Open your browser and download latest version https://dotnet.microsoft.com/download/dotnet


Then extract this zip and run ViperionV2.exe 
if it wont work as Administrator

REEEEEEEEAAADDD:
Troubleshooting

- Make sure u have installed .NET Runtime (latest Version)
- If it wont launch / then as admin
- IF ALL THAT DIDNT FIX YOUR ERRORS then:
either contact @Teiyli a Server owner or email
teiylicet@gmail.com